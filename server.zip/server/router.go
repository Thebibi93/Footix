/*
Ce fichier va centraliser la définition des points d'entrée (endpoints).
Pour ce projet de prédiction, nous avons besoin d'au moins deux routes majeures :
une pour la liste des matchs et l'autre pour les statistiques de prédiction d'un match précis.
*/
package main

import (
	"crypto/sha256"
	"database/sql"
	"encoding/hex"
	"encoding/json"
	"errors"
	"footix/storage"
	"net/http"
	"strconv"
	"strings"
	"time"
)

const sessionCookieName = "footix_user_id"

// ==================   POINTS IMPORTANTS ==================
// 1. Chaque route est définie via http.HandleFunc, qui associe une URL à une fonction handler.
// 2. Les handlers sont des fonctions qui prennent en paramètre http.ResponseWriter et *http.Request.
// 3. La communication avec le client se fait exclusivement via JSON, en utilisant json.NewEncoder pour encoder les réponses.
// 4. Les handlers font appel à la couche de stockage pour récupérer ou manipuler les données nécessaires.
// 5. Le CORS est géré au niveau de chaque handler pour permettre les requêtes depuis le client React (en dev local).

/*
  HTTP, appelle le package storage, et renvoie du JSON.
  CORS (Cross-Origin Resource Sharing) :
  Le client React (souvent sur le port 5173) est considéré comme une
  origine différente de notre serveur Go (port 8080).
  Sans le header Access-Control-Allow-Origin, le navigateur bloquera la requête.
  Asynchronisme (AJAX) : Le client React utilisera fetch() pour appeler
  ces routes de manière asynchrone.
*/

/*  Petit descriptif

// Authentification et gestion des utilisateurs
// on a un bouton "Login" sur la page d'accueil, qui redirige vers une page de login
// on a un bouton "signup" sur la page d'accueil, qui redirige vers une page de sign up
// on a un bouton "Logout" sur la page d'accueil, qui redirige vers une page de logout
// on a un bouton "Profile" sur la page d'accueil, qui redirige vers une page de profile
// on a un bouton "My Predictions" dans le profil, qui recharge de manière asynchrone la liste des prédictions faites par l'utilisateur
// juste un petit volume lorsque l'utilisateur clique sur "My Predictions", on affiche une liste de ses prédictions passées (match, résultat prédit, résultat réel, date de la prédiction)
// qui surcharge la page de profil, et on peut revenir à la page d'accueil en cliquant sur un bouton "Back to Home" ou quelque chose du genre

// On peut aussi obtenir des infos des utilisateurs par ID
// si on est connecté, on peut aussi faire une route pour obtenir les infos de l'utilisateur connecté (ex: /api/me) et aussi une route pour mettre à jour les infos de l'utilisateur (ex: /api/updateProfile)
// et aussi afficher les infos des autres utilisateurs connectés mais pas toutes leurs infos sensibles on a un sys de chat



// Home page (on aura des boutons pour chaque ligue puis une fois qu'on clique sur une ligue,
// on affiche les matchs à venir (pas encore joué à cette heure actuelle de cette ligue)
// maintenant on est sur un match à venir on voit deux équipe
// on peut cliquer sur un match et on voit les stats de ce match
// (probabilité de victoire de chaque équipe et de nul, et aussi les derniers résultats des deux équipes)

*/

// RegisterRoutes configure tous les points d'entrée de l'API
// RegisterRoutes configure tous les points d'entrée de l'API
func RegisterRoutes(db *sql.DB) {

	// ========== ============================ =========================
	//  ===== ======== ==== Côté GET ===== ======= ======== ====
	// ========== ============================ =========================

	// Usage :
	// - GET  /api/profile                -> obtenir les infos du profil de l'utilisateur connecté
	// - POST /api/profile                -> mettre à jour le profil (ex: {"email":"test@mail.com","password":"newpass"})
	// - POST /api/update-profile         -> alias explicite pour la mise à jour du profil
	http.HandleFunc("/api/profile", func(w http.ResponseWriter, r *http.Request) {
		switch r.Method {
		case http.MethodGet:
			profileHandler(w, r, db)
		case http.MethodPost:
			updateProfileHandler(w, r, db)
		default:
			http.Error(w, "Méthode non autorisée", http.StatusMethodNotAllowed)
		}
	})

	// Usage :
	// - GET /api/my-predictions          -> obtenir la liste des prédictions de l'utilisateur connecté
	http.HandleFunc("/api/my-predictions", func(w http.ResponseWriter, r *http.Request) {
		if r.Method != http.MethodGet {
			http.Error(w, "Méthode non autorisée", http.StatusMethodNotAllowed)
			return
		}
		myPredictionsHandler(w, r, db)
	})

	// Usage :
	// - GET /api/users                   -> obtenir la liste de tous les utilisateurs (pour le sys de chat)
	// - GET /api/users?userId=123        -> obtenir les infos d'un utilisateur spécifique (pour le sys de chat)
	http.HandleFunc("/api/users", func(w http.ResponseWriter, r *http.Request) {
		if r.Method != http.MethodGet {
			http.Error(w, "Méthode non autorisée", http.StatusMethodNotAllowed)
			return
		}

		if r.URL.Query().Get("userId") != "" {
			getUserByIdHandler(w, r, db)
			return
		}

		getUsersHandler(w, r, db)
	})

	// Route pour tester la connexion (déjà faite)
	// Usage :
	// - GET /api/hello                   -> tester que le serveur répond bien
	http.HandleFunc("/api/hello", helloHandler)

	// Route pour récupérer les matchs d'une ligue
	// Usage :
	// - GET /api/matches?league=FL1      -> récupérer les matchs d'une ligue
	http.HandleFunc("/api/matches", func(w http.ResponseWriter, r *http.Request) {
		if r.Method != http.MethodGet {
			http.Error(w, "Méthode non autorisée", http.StatusMethodNotAllowed)
			return
		}
		getMatchesHandler(w, r, db)
	})

	// Route pour obtenir des statistiques d'un match spécifique
	// Usage :
	// - GET /api/stats?matchId=123       -> obtenir les stats d'un match
	http.HandleFunc("/api/stats", func(w http.ResponseWriter, r *http.Request) {
		if r.Method != http.MethodGet {
			http.Error(w, "Méthode non autorisée", http.StatusMethodNotAllowed)
			return
		}
		getStatsHandler(w, r, db)
	})

	// Usage :
	// - GET  /api/scores                 -> obtenir le classement des utilisateurs
	// - POST /api/scores                 -> recalculer les scores des utilisateurs
	http.HandleFunc("/api/scores", func(w http.ResponseWriter, r *http.Request) {
		switch r.Method {
		case http.MethodGet:
			getScoresHandler(w, r, db)
		case http.MethodPost:
			recalculateScoresHandler(w, r, db)
		default:
			http.Error(w, "Méthode non autorisée", http.StatusMethodNotAllowed)
		}
	})

	// Usage :
	// - GET /api/feedbacks?matchId=123               -> obtenir les feedbacks d'un match donné
	// - GET /api/feedbacks?userId=456                -> obtenir les feedbacks d'un utilisateur donné
	// - GET /api/feedbacks?matchId=123&afterSeq=99   -> obtenir uniquement les nouveaux feedbacks après la séquence 99
	http.HandleFunc("/api/feedbacks", func(w http.ResponseWriter, r *http.Request) {
		if r.Method != http.MethodGet {
			http.Error(w, "Méthode non autorisée", http.StatusMethodNotAllowed)
			return
		}
		getFeedbacksHandler(w, r, db)
	})

	// ========== ============================ =========================
	//  ===== ======== ==== Côté POST ===== ======= ======== ====
	// ========== ============================ =========================

	// Usage :
	// - POST /api/login                  -> connexion avec body JSON {"username":"idris","password":"secret"}
	http.HandleFunc("/api/login", func(w http.ResponseWriter, r *http.Request) {
		if r.Method != http.MethodPost {
			http.Error(w, "Méthode non autorisée", http.StatusMethodNotAllowed)
			return
		}
		loginHandler(w, r, db)
	})

	// Usage :
	// - POST /api/signup                 -> inscription avec body JSON {"username":"idris","email":"idris@mail.com","password":"secret"}
	http.HandleFunc("/api/signup", func(w http.ResponseWriter, r *http.Request) {
		if r.Method != http.MethodPost {
			http.Error(w, "Méthode non autorisée", http.StatusMethodNotAllowed)
			return
		}
		signupHandler(w, r, db)
	})

	// Usage :
	// - POST /api/logout                 -> déconnexion (pas besoin de body, on se base sur la session/cookie)
	http.HandleFunc("/api/logout", func(w http.ResponseWriter, r *http.Request) {
		if r.Method != http.MethodPost {
			http.Error(w, "Méthode non autorisée", http.StatusMethodNotAllowed)
			return
		}
		logoutHandler(w, r, db)
	})

	// Usage :
	// - POST /api/update-profile         -> mettre à jour le profil avec body JSON {"email":"new@mail.com","password":"newpass"}
	http.HandleFunc("/api/update-profile", func(w http.ResponseWriter, r *http.Request) {
		if r.Method != http.MethodPost {
			http.Error(w, "Méthode non autorisée", http.StatusMethodNotAllowed)
			return
		}
		updateProfileHandler(w, r, db)
	})

	// Usage :
	// - POST /api/predict                -> soumettre une prédiction avec body JSON {"matchId":123,"predictedResult":"HOME_WIN"}
	http.HandleFunc("/api/predict", func(w http.ResponseWriter, r *http.Request) {
		if r.Method != http.MethodPost {
			http.Error(w, "Méthode non autorisée", http.StatusMethodNotAllowed)
			return
		}
		submitPredictionHandler(w, r, db)
	})

	// Usage :
	// - POST /api/feedback               -> envoyer un feedback avec body JSON {"matchId":123,"message":"Très beau match"}
	http.HandleFunc("/api/feedback", func(w http.ResponseWriter, r *http.Request) {
		if r.Method != http.MethodPost {
			http.Error(w, "Méthode non autorisée", http.StatusMethodNotAllowed)
			return
		}
		submitFeedbackHandler(w, r, db)
	})
}

//=========================================================================================================================================//
//=========================================================================================================================================//
//=========================================================================================================================================//
//====================================================Implémentation des CallBack==========================================================//
//=========================================================================================================================================//
//=========================================================================================================================================//
//=========================================================================================================================================//
//=========================================================================================================================================//
//=========================================================================================================================================//

// =========================
// Helpers HTTP / JSON / CORS
// =========================

func setCommonHeaders(w http.ResponseWriter, r *http.Request) {
	origin := r.Header.Get("Origin")
	if origin == "" {
		origin = "*"
	}
	w.Header().Set("Access-Control-Allow-Origin", origin)
	w.Header().Set("Vary", "Origin")
	w.Header().Set("Access-Control-Allow-Methods", "GET, POST, PUT, PATCH, DELETE, OPTIONS")
	w.Header().Set("Access-Control-Allow-Headers", "Content-Type, Authorization, X-User-ID")
	w.Header().Set("Access-Control-Allow-Credentials", "true")
	w.Header().Set("Content-Type", "application/json; charset=utf-8")
}

// cette
func handlePreflight(w http.ResponseWriter, r *http.Request) bool {
	setCommonHeaders(w, r)
	if r.Method == http.MethodOptions {
		w.WriteHeader(http.StatusNoContent)
		return true
	}
	return false
}

func writeJSON(w http.ResponseWriter, r *http.Request, status int, payload any) {
	setCommonHeaders(w, r)
	w.WriteHeader(status)
	_ = json.NewEncoder(w).Encode(payload)
}

func writeError(w http.ResponseWriter, r *http.Request, status int, message string) {
	writeJSON(w, r, status, map[string]string{"error": message})
}

func decodeJSONBody(r *http.Request, dst any) error {
	defer r.Body.Close()
	dec := json.NewDecoder(r.Body)
	dec.DisallowUnknownFields()
	return dec.Decode(dst)
}

// Package sha256 implements the SHA224 and SHA256 hash algorithms as defined in FIPS 180-4.
func hashPassword(password string) string {
	sum := sha256.Sum256([]byte(password))
	return hex.EncodeToString(sum[:])
}

func passwordMatches(storedValue, plainPassword string) bool {
	if storedValue == "" {
		return false
	}
	candidate := hashPassword(plainPassword)
	return storedValue == candidate || storedValue == plainPassword
}

func setSessionCookie(w http.ResponseWriter, userID int) {
	http.SetCookie(w, &http.Cookie{
		Name:     sessionCookieName,
		Value:    strconv.Itoa(userID),
		Path:     "/",
		HttpOnly: true,
		SameSite: http.SameSiteLaxMode,
		MaxAge:   7 * 24 * 60 * 60,
	})
}

func clearSessionCookie(w http.ResponseWriter) {
	http.SetCookie(w, &http.Cookie{
		Name:     sessionCookieName,
		Value:    "",
		Path:     "/",
		HttpOnly: true,
		SameSite: http.SameSiteLaxMode,
		MaxAge:   -1,
		Expires:  time.Unix(0, 0),
	})
}

func getAuthenticatedUserID(r *http.Request) (int, error) {
	if cookie, err := r.Cookie(sessionCookieName); err == nil {
		id, convErr := strconv.Atoi(cookie.Value)
		if convErr == nil && id > 0 {
			return id, nil
		}
	}

	// petit fallback pratique pour tester rapidement côté dev / Postman
	if header := strings.TrimSpace(r.Header.Get("X-User-ID")); header != "" {
		id, err := strconv.Atoi(header)
		if err == nil && id > 0 {
			return id, nil
		}
	}

	return 0, errors.New("utilisateur non authentifié")
}

func normalizePredictionResult(value string) (string, error) {
	switch strings.ToUpper(strings.TrimSpace(value)) {
	case "1", "HOME", "HOME_WIN", "HOMEWIN", "DOMICILE":
		return "HOME_WIN", nil
	case "X", "DRAW", "NUL":
		return "DRAW", nil
	case "2", "AWAY", "AWAY_WIN", "AWAYWIN", "EXTERIEUR", "EXTÉRIEUR":
		return "AWAY_WIN", nil
	default:
		return "", errors.New("predictedResult doit valoir HOME_WIN, DRAW ou AWAY_WIN")
	}
}

func actualResultFromScores(homeScore, awayScore sql.NullInt64) string {
	if !homeScore.Valid || !awayScore.Valid {
		return ""
	}
	if homeScore.Int64 > awayScore.Int64 {
		return "HOME_WIN"
	}
	if awayScore.Int64 > homeScore.Int64 {
		return "AWAY_WIN"
	}
	return "DRAW"
}

func getLastResultsString(db *sql.DB, teamID int, limit int) string {
	query := `
		SELECT home_team_id, away_team_id, home_score, away_score
		FROM Matches
		WHERE status = 'FINISHED'
		  AND (home_team_id = $1 OR away_team_id = $1)
		ORDER BY utc_date DESC
		LIMIT $2`

	rows, err := db.Query(query, teamID, limit)
	if err != nil {
		return ""
	}
	defer rows.Close()

	results := make([]string, 0, limit)
	for rows.Next() {
		var homeID, awayID int
		var homeScore, awayScore sql.NullInt64
		if err := rows.Scan(&homeID, &awayID, &homeScore, &awayScore); err != nil {
			return strings.Join(results, " ")
		}
		if !homeScore.Valid || !awayScore.Valid {
			continue
		}
		if teamID == homeID {
			switch {
			case homeScore.Int64 > awayScore.Int64:
				results = append(results, "W")
			case homeScore.Int64 == awayScore.Int64:
				results = append(results, "D")
			default:
				results = append(results, "L")
			}
		} else {
			switch {
			case awayScore.Int64 > homeScore.Int64:
				results = append(results, "W")
			case awayScore.Int64 == homeScore.Int64:
				results = append(results, "D")
			default:
				results = append(results, "L")
			}
		}
	}
	return strings.Join(results, " ")
}

// =========================
// GET routes
// =========================

func getMatchesHandler(w http.ResponseWriter, r *http.Request, db *sql.DB) {
	if handlePreflight(w, r) {
		return
	}
	if r.Method != http.MethodGet {
		writeError(w, r, http.StatusMethodNotAllowed, "Méthode non autorisée")
		return
	}

	leagueCode := strings.TrimSpace(r.URL.Query().Get("league"))
	if leagueCode == "" {
		writeError(w, r, http.StatusBadRequest, "Le paramètre 'league' est requis")
		return
	}

	matches, err := storage.GetMatchesByLeague(db, leagueCode)
	if err != nil {
		writeError(w, r, http.StatusInternalServerError, "Erreur lors de la récupération des matchs")
		return
	}

	writeJSON(w, r, http.StatusOK, matches)
}

func getStatsHandler(w http.ResponseWriter, r *http.Request, db *sql.DB) {
	if handlePreflight(w, r) {
		return
	}
	if r.Method != http.MethodGet {
		writeError(w, r, http.StatusMethodNotAllowed, "Méthode non autorisée")
		return
	}

	matchID := strings.TrimSpace(r.URL.Query().Get("matchId"))
	if matchID == "" {
		writeError(w, r, http.StatusBadRequest, "Paramètre matchId manquant")
		return
	}

	stats, err := storage.GetMatchStats(db, matchID)
	if err != nil {
		writeError(w, r, http.StatusInternalServerError, "Erreur lors du calcul des statistiques")
		return
	}

	var homeID, awayID int
	err = db.QueryRow(`SELECT home_team_id, away_team_id FROM Matches WHERE id = $1`, matchID).Scan(&homeID, &awayID)
	if err == nil {
		stats.HomeLastResults = getLastResultsString(db, homeID, 5)
		stats.AwayLastResults = getLastResultsString(db, awayID, 5)
	}

	writeJSON(w, r, http.StatusOK, stats)
}

func profileHandler(w http.ResponseWriter, r *http.Request, db *sql.DB) {
	if handlePreflight(w, r) {
		return
	}

	switch r.Method {
	case http.MethodGet:
		userID, err := getAuthenticatedUserID(r)
		if err != nil {
			writeError(w, r, http.StatusUnauthorized, "Utilisateur non connecté")
			return
		}

		var user struct {
			ID       int    `json:"id"`
			Username string `json:"username"`
			Email    string `json:"email"`
		}

		err = db.QueryRow(`SELECT id, username, email FROM "User" WHERE id = $1`, userID).Scan(&user.ID, &user.Username, &user.Email)
		if err == sql.ErrNoRows {
			writeError(w, r, http.StatusNotFound, "Utilisateur introuvable")
			return
		}
		if err != nil {
			writeError(w, r, http.StatusInternalServerError, "Erreur lors de la récupération du profil")
			return
		}

		writeJSON(w, r, http.StatusOK, user)

	case http.MethodPost:
		updateProfileHandler(w, r, db)

	default:
		writeError(w, r, http.StatusMethodNotAllowed, "Méthode non autorisée")
	}
}

func myPredictionsHandler(w http.ResponseWriter, r *http.Request, db *sql.DB) {
	if handlePreflight(w, r) {
		return
	}
	if r.Method != http.MethodGet {
		writeError(w, r, http.StatusMethodNotAllowed, "Méthode non autorisée")
		return
	}

	userID, err := getAuthenticatedUserID(r)
	if err != nil {
		writeError(w, r, http.StatusUnauthorized, "Utilisateur non connecté")
		return
	}

	query := `
		SELECT
			h.user_id,
			h.match_id,
			h.predicted_result,
			COALESCE(h.actual_result, ''),
			TO_CHAR(h.prediction_date AT TIME ZONE 'UTC', 'YYYY-MM-DD"T"HH24:MI:SS"Z"'),
			hm.name,
			am.name,
			m.utc_date
		FROM UserPredictionHistory h
		JOIN Matches m ON m.id = h.match_id
		JOIN Teams hm ON hm.id = m.home_team_id
		JOIN Teams am ON am.id = m.away_team_id
		WHERE h.user_id = $1
		ORDER BY h.prediction_date DESC`

	rows, err := db.Query(query, userID)
	if err != nil {
		writeError(w, r, http.StatusInternalServerError, "Erreur lors de la récupération des prédictions")
		return
	}
	defer rows.Close()

	type predictionRow struct {
		UserID          int    `json:"userId"`
		MatchID         int    `json:"matchId"`
		PredictedResult string `json:"predictedResult"`
		ActualResult    string `json:"actualResult,omitempty"`
		PredictionDate  string `json:"predictionDate"`
		HomeTeam        string `json:"homeTeam"`
		AwayTeam        string `json:"awayTeam"`
		MatchDate       string `json:"matchDate"`
	}

	predictions := make([]predictionRow, 0)
	for rows.Next() {
		var item predictionRow
		var matchDate time.Time
		if err := rows.Scan(
			&item.UserID,
			&item.MatchID,
			&item.PredictedResult,
			&item.ActualResult,
			&item.PredictionDate,
			&item.HomeTeam,
			&item.AwayTeam,
			&matchDate,
		); err != nil {
			writeError(w, r, http.StatusInternalServerError, "Erreur lors de la lecture des prédictions")
			return
		}
		item.MatchDate = matchDate.UTC().Format(time.RFC3339)
		predictions = append(predictions, item)
	}

	writeJSON(w, r, http.StatusOK, predictions)
}

func usersHandler(w http.ResponseWriter, r *http.Request, db *sql.DB) {
	if handlePreflight(w, r) {
		return
	}
	if r.Method != http.MethodGet {
		writeError(w, r, http.StatusMethodNotAllowed, "Méthode non autorisée")
		return
	}

	if userIDStr := strings.TrimSpace(r.URL.Query().Get("userId")); userIDStr != "" {
		getUserByIdHandler(w, r, db)
		return
	}
	getUsersHandler(w, r, db)
}

func getUsersHandler(w http.ResponseWriter, r *http.Request, db *sql.DB) {
	rows, err := db.Query(`SELECT id, username FROM "User" ORDER BY username ASC`)
	if err != nil {
		writeError(w, r, http.StatusInternalServerError, "Erreur lors de la récupération des utilisateurs")
		return
	}
	defer rows.Close()

	users := make([]map[string]any, 0)
	for rows.Next() {
		var id int
		var username string
		if err := rows.Scan(&id, &username); err != nil {
			writeError(w, r, http.StatusInternalServerError, "Erreur lors de la lecture des utilisateurs")
			return
		}
		users = append(users, map[string]any{
			"id":       id,
			"username": username,
		})
	}

	writeJSON(w, r, http.StatusOK, users)
}

func getUserByIdHandler(w http.ResponseWriter, r *http.Request, db *sql.DB) {
	userID, err := strconv.Atoi(strings.TrimSpace(r.URL.Query().Get("userId")))
	if err != nil || userID <= 0 {
		writeError(w, r, http.StatusBadRequest, "Paramètre userId invalide")
		return
	}

	var user struct {
		ID       int    `json:"id"`
		Username string `json:"username"`
	}

	err = db.QueryRow(`SELECT id, username FROM "User" WHERE id = $1`, userID).Scan(&user.ID, &user.Username)
	if err == sql.ErrNoRows {
		writeError(w, r, http.StatusNotFound, "Utilisateur introuvable")
		return
	}
	if err != nil {
		writeError(w, r, http.StatusInternalServerError, "Erreur lors de la récupération de l'utilisateur")
		return
	}

	writeJSON(w, r, http.StatusOK, user)
}

func scoresHandler(w http.ResponseWriter, r *http.Request, db *sql.DB) {
	if handlePreflight(w, r) {
		return
	}

	switch r.Method {
	case http.MethodGet:
		getScoresHandler(w, r, db)
	case http.MethodPost:
		recalculateScoresHandler(w, r, db)
	default:
		writeError(w, r, http.StatusMethodNotAllowed, "Méthode non autorisée")
	}
}

func getScoresHandler(w http.ResponseWriter, r *http.Request, db *sql.DB) {
	query := `
		SELECT u.id, u.username, COALESCE(s.score, 0) AS score
		FROM "User" u
		LEFT JOIN UserScores s ON s.user_id = u.id
		ORDER BY score DESC, u.username ASC`

	rows, err := db.Query(query)
	if err != nil {
		writeError(w, r, http.StatusInternalServerError, "Erreur lors de la récupération du classement")
		return
	}
	defer rows.Close()

	leaderboard := make([]map[string]any, 0)
	for rows.Next() {
		var userID int
		var username string
		var score int
		if err := rows.Scan(&userID, &username, &score); err != nil {
			writeError(w, r, http.StatusInternalServerError, "Erreur lors de la lecture du classement")
			return
		}
		leaderboard = append(leaderboard, map[string]any{
			"userId":   userID,
			"username": username,
			"score":    score,
		})
	}

	writeJSON(w, r, http.StatusOK, leaderboard)
}

func feedbacksHandler(w http.ResponseWriter, r *http.Request, db *sql.DB) {
	if handlePreflight(w, r) {
		return
	}

	switch r.Method {
	case http.MethodGet:
		getFeedbacksHandler(w, r, db)
	case http.MethodPost:
		submitFeedbackHandler(w, r, db)
	default:
		writeError(w, r, http.StatusMethodNotAllowed, "Méthode non autorisée")
	}
}

func getFeedbacksHandler(w http.ResponseWriter, r *http.Request, db *sql.DB) {
	matchIDStr := strings.TrimSpace(r.URL.Query().Get("matchId"))
	userIDStr := strings.TrimSpace(r.URL.Query().Get("userId"))
	afterSeqStr := strings.TrimSpace(r.URL.Query().Get("afterSeq"))
	limitStr := strings.TrimSpace(r.URL.Query().Get("limit"))

	limit := 100
	if limitStr != "" {
		if parsed, err := strconv.Atoi(limitStr); err == nil && parsed > 0 && parsed <= 500 {
			limit = parsed
		}
	}

	if matchIDStr == "" && userIDStr == "" {
		writeError(w, r, http.StatusBadRequest, "Il faut fournir matchId ou userId")
		return
	}

	type feedbackRow struct {
		ID           int64  `json:"id"`
		MatchID      int64  `json:"matchId"`
		SeqInChat    int64  `json:"seqInChat"`
		UserID       int64  `json:"userId"`
		Username     string `json:"username"`
		Message      string `json:"message"`
		FeedbackDate string `json:"feedbackDate"`
	}

	var (
		rows *sql.Rows
		err  error
	)

	switch {
	case matchIDStr != "":
		matchID, convErr := strconv.ParseInt(matchIDStr, 10, 64)
		if convErr != nil || matchID <= 0 {
			writeError(w, r, http.StatusBadRequest, "Paramètre matchId invalide")
			return
		}

		afterSeq := int64(0)
		if afterSeqStr != "" {
			afterSeq, convErr = strconv.ParseInt(afterSeqStr, 10, 64)
			if convErr != nil || afterSeq < 0 {
				writeError(w, r, http.StatusBadRequest, "Paramètre afterSeq invalide")
				return
			}
		}

		rows, err = db.Query(`
			SELECT f.id, f.match_id, f.seq_in_chat, f.user_id, u.username, f.message,
			       TO_CHAR(f.feedback_date AT TIME ZONE 'UTC', 'YYYY-MM-DD"T"HH24:MI:SS"Z"')
			FROM Feedback f
			JOIN "User" u ON u.id = f.user_id
			WHERE f.match_id = $1 AND f.seq_in_chat > $2
			ORDER BY f.seq_in_chat ASC
			LIMIT $3`, matchID, afterSeq, limit)

	case userIDStr != "":
		userID, convErr := strconv.ParseInt(userIDStr, 10, 64)
		if convErr != nil || userID <= 0 {
			writeError(w, r, http.StatusBadRequest, "Paramètre userId invalide")
			return
		}

		rows, err = db.Query(`
			SELECT f.id, f.match_id, f.seq_in_chat, f.user_id, u.username, f.message,
			       TO_CHAR(f.feedback_date AT TIME ZONE 'UTC', 'YYYY-MM-DD"T"HH24:MI:SS"Z"')
			FROM Feedback f
			JOIN "User" u ON u.id = f.user_id
			WHERE f.user_id = $1
			ORDER BY f.feedback_date DESC
			LIMIT $2`, userID, limit)
	}

	if err != nil {
		writeError(w, r, http.StatusInternalServerError, "Erreur lors de la récupération des feedbacks")
		return
	}
	defer rows.Close()

	feedbacks := make([]feedbackRow, 0)
	for rows.Next() {
		var item feedbackRow
		if err := rows.Scan(&item.ID, &item.MatchID, &item.SeqInChat, &item.UserID, &item.Username, &item.Message, &item.FeedbackDate); err != nil {
			writeError(w, r, http.StatusInternalServerError, "Erreur lors de la lecture des feedbacks")
			return
		}
		feedbacks = append(feedbacks, item)
	}

	writeJSON(w, r, http.StatusOK, feedbacks)
}

// =========================
// POST routes
// =========================

type authPayload struct {
	Username string `json:"username"`
	Email    string `json:"email"`
	Password string `json:"password"`
}

type updateProfilePayload struct {
	Username string `json:"username"`
	Email    string `json:"email"`
	Password string `json:"password"`
}

type predictionPayload struct {
	MatchID         int    `json:"matchId"`
	PredictedResult string `json:"predictedResult"`
}

type feedbackPayload struct {
	MatchID int    `json:"matchId"`
	Message string `json:"message"`
}

func loginHandler(w http.ResponseWriter, r *http.Request, db *sql.DB) {
	if handlePreflight(w, r) {
		return
	}
	if r.Method != http.MethodPost {
		writeError(w, r, http.StatusMethodNotAllowed, "Méthode non autorisée")
		return
	}

	var payload authPayload
	if err := decodeJSONBody(r, &payload); err != nil {
		writeError(w, r, http.StatusBadRequest, "Corps JSON invalide")
		return
	}

	identifier := strings.TrimSpace(payload.Username)
	password := payload.Password
	if identifier == "" && strings.TrimSpace(payload.Email) != "" {
		identifier = strings.TrimSpace(payload.Email)
	}
	if identifier == "" || strings.TrimSpace(password) == "" {
		writeError(w, r, http.StatusBadRequest, "username/email et password sont requis")
		return
	}

	var userID int
	var username, email, passwordHash string
	err := db.QueryRow(`
		SELECT id, username, email, password_hash
		FROM "User"
		WHERE username = $1 OR email = $1`, identifier).Scan(&userID, &username, &email, &passwordHash)
	if err == sql.ErrNoRows {
		writeError(w, r, http.StatusUnauthorized, "Identifiants invalides")
		return
	}
	if err != nil {
		writeError(w, r, http.StatusInternalServerError, "Erreur lors du login")
		return
	}

	if !passwordMatches(passwordHash, password) {
		writeError(w, r, http.StatusUnauthorized, "Identifiants invalides")
		return
	}

	setSessionCookie(w, userID)
	writeJSON(w, r, http.StatusOK, map[string]any{
		"message": "Connexion réussie",
		"user": map[string]any{
			"id":       userID,
			"username": username,
			"email":    email,
		},
	})
}

func signupHandler(w http.ResponseWriter, r *http.Request, db *sql.DB) {
	if handlePreflight(w, r) {
		return
	}
	if r.Method != http.MethodPost {
		writeError(w, r, http.StatusMethodNotAllowed, "Méthode non autorisée")
		return
	}

	var payload authPayload
	if err := decodeJSONBody(r, &payload); err != nil {
		writeError(w, r, http.StatusBadRequest, "Corps JSON invalide")
		return
	}

	payload.Username = strings.TrimSpace(payload.Username)
	payload.Email = strings.TrimSpace(payload.Email)
	payload.Password = strings.TrimSpace(payload.Password)

	if payload.Username == "" || payload.Email == "" || payload.Password == "" {
		writeError(w, r, http.StatusBadRequest, "username, email et password sont requis")
		return
	}

	var userID int
	err := db.QueryRow(`
		INSERT INTO "User" (username, email, password_hash)
		VALUES ($1, $2, $3)
		RETURNING id`, payload.Username, payload.Email, hashPassword(payload.Password)).Scan(&userID)
	if err != nil {
		writeError(w, r, http.StatusBadRequest, "Impossible de créer le compte (username ou email déjà utilisé)")
		return
	}

	_, _ = db.Exec(`INSERT INTO UserScores (user_id, score) VALUES ($1, 0) ON CONFLICT (user_id) DO NOTHING`, userID)
	setSessionCookie(w, userID)

	writeJSON(w, r, http.StatusCreated, map[string]any{
		"message": "Compte créé",
		"user": map[string]any{
			"id":       userID,
			"username": payload.Username,
			"email":    payload.Email,
		},
	})
}

func logoutHandler(w http.ResponseWriter, r *http.Request, db *sql.DB) {
	_ = db
	if handlePreflight(w, r) {
		return
	}
	if r.Method != http.MethodPost {
		writeError(w, r, http.StatusMethodNotAllowed, "Méthode non autorisée")
		return
	}

	clearSessionCookie(w)
	writeJSON(w, r, http.StatusOK, map[string]string{"message": "Déconnexion réussie"})
}

func updateProfileHandler(w http.ResponseWriter, r *http.Request, db *sql.DB) {
	if handlePreflight(w, r) {
		return
	}
	if r.Method != http.MethodPost {
		writeError(w, r, http.StatusMethodNotAllowed, "Méthode non autorisée")
		return
	}

	userID, err := getAuthenticatedUserID(r)
	if err != nil {
		writeError(w, r, http.StatusUnauthorized, "Utilisateur non connecté")
		return
	}

	var payload updateProfilePayload
	if err := decodeJSONBody(r, &payload); err != nil {
		writeError(w, r, http.StatusBadRequest, "Corps JSON invalide")
		return
	}

	payload.Username = strings.TrimSpace(payload.Username)
	payload.Email = strings.TrimSpace(payload.Email)
	payload.Password = strings.TrimSpace(payload.Password)

	var currentUsername, currentEmail, currentPasswordHash string
	err = db.QueryRow(`SELECT username, email, password_hash FROM "User" WHERE id = $1`, userID).
		Scan(&currentUsername, &currentEmail, &currentPasswordHash)
	if err == sql.ErrNoRows {
		writeError(w, r, http.StatusNotFound, "Utilisateur introuvable")
		return
	}
	if err != nil {
		writeError(w, r, http.StatusInternalServerError, "Erreur lors de la récupération du profil")
		return
	}

	newUsername := currentUsername
	newEmail := currentEmail
	newPasswordHash := currentPasswordHash

	if payload.Username != "" {
		newUsername = payload.Username
	}
	if payload.Email != "" {
		newEmail = payload.Email
	}
	if payload.Password != "" {
		newPasswordHash = hashPassword(payload.Password)
	}

	_, err = db.Exec(`
		UPDATE "User"
		SET username = $1, email = $2, password_hash = $3
		WHERE id = $4`, newUsername, newEmail, newPasswordHash, userID)
	if err != nil {
		writeError(w, r, http.StatusBadRequest, "Impossible de mettre à jour le profil")
		return
	}

	writeJSON(w, r, http.StatusOK, map[string]any{
		"message": "Profil mis à jour",
		"user": map[string]any{
			"id":       userID,
			"username": newUsername,
			"email":    newEmail,
		},
	})
}

func submitPredictionHandler(w http.ResponseWriter, r *http.Request, db *sql.DB) {
	if handlePreflight(w, r) {
		return
	}
	if r.Method != http.MethodPost {
		writeError(w, r, http.StatusMethodNotAllowed, "Méthode non autorisée")
		return
	}

	userID, err := getAuthenticatedUserID(r)
	if err != nil {
		writeError(w, r, http.StatusUnauthorized, "Utilisateur non connecté")
		return
	}

	var payload predictionPayload
	if err := decodeJSONBody(r, &payload); err != nil {
		writeError(w, r, http.StatusBadRequest, "Corps JSON invalide")
		return
	}

	if payload.MatchID <= 0 {
		writeError(w, r, http.StatusBadRequest, "matchId invalide")
		return
	}

	normalizedResult, err := normalizePredictionResult(payload.PredictedResult)
	if err != nil {
		writeError(w, r, http.StatusBadRequest, err.Error())
		return
	}

	var status string
	var homeScore, awayScore sql.NullInt64
	err = db.QueryRow(`SELECT status, home_score, away_score FROM Matches WHERE id = $1`, payload.MatchID).
		Scan(&status, &homeScore, &awayScore)
	if err == sql.ErrNoRows {
		writeError(w, r, http.StatusNotFound, "Match introuvable")
		return
	}
	if err != nil {
		writeError(w, r, http.StatusInternalServerError, "Erreur lors de la récupération du match")
		return
	}

	if status == "FINISHED" {
		writeError(w, r, http.StatusBadRequest, "Impossible de prédire un match déjà terminé")
		return
	}

	_, err = db.Exec(`
		INSERT INTO UserPredictions (user_id, match_id, predicted_result)
		VALUES ($1, $2, $3)
		ON CONFLICT (user_id, match_id) DO UPDATE
		SET predicted_result = EXCLUDED.predicted_result`, userID, payload.MatchID, normalizedResult)
	if err != nil {
		writeError(w, r, http.StatusInternalServerError, "Erreur lors de l'enregistrement de la prédiction")
		return
	}

	actualResult := actualResultFromScores(homeScore, awayScore)
	_, err = db.Exec(`
		INSERT INTO UserPredictionHistory (user_id, match_id, predicted_result, actual_result, prediction_date)
		VALUES ($1, $2, $3, $4, NOW())
		ON CONFLICT (user_id, match_id) DO UPDATE
		SET predicted_result = EXCLUDED.predicted_result,
		    actual_result = EXCLUDED.actual_result,
		    prediction_date = NOW()`, userID, payload.MatchID, normalizedResult, actualResult)
	if err != nil {
		writeError(w, r, http.StatusInternalServerError, "Erreur lors de la mise à jour de l'historique des prédictions")
		return
	}

	writeJSON(w, r, http.StatusOK, map[string]any{
		"message":         "Prédiction enregistrée",
		"userId":          userID,
		"matchId":         payload.MatchID,
		"predictedResult": normalizedResult,
	})
}

func submitFeedbackHandler(w http.ResponseWriter, r *http.Request, db *sql.DB) {
	if handlePreflight(w, r) {
		return
	}
	if r.Method != http.MethodPost {
		writeError(w, r, http.StatusMethodNotAllowed, "Méthode non autorisée")
		return
	}

	userID, err := getAuthenticatedUserID(r)
	if err != nil {
		writeError(w, r, http.StatusUnauthorized, "Utilisateur non connecté")
		return
	}

	var payload feedbackPayload
	if err := decodeJSONBody(r, &payload); err != nil {
		writeError(w, r, http.StatusBadRequest, "Corps JSON invalide")
		return
	}

	payload.Message = strings.TrimSpace(payload.Message)
	if payload.MatchID <= 0 {
		writeError(w, r, http.StatusBadRequest, "matchId invalide")
		return
	}
	if payload.Message == "" {
		writeError(w, r, http.StatusBadRequest, "message requis")
		return
	}

	for attempt := 0; attempt < 3; attempt++ {
		tx, err := db.BeginTx(r.Context(), &sql.TxOptions{Isolation: sql.LevelSerializable})
		if err != nil {
			writeError(w, r, http.StatusInternalServerError, "Impossible d'ouvrir la transaction")
			return
		}

		var nextSeq int64 = 1
		if err := tx.QueryRow(`SELECT COALESCE(MAX(seq_in_chat), 0) + 1 FROM Feedback WHERE match_id = $1`, payload.MatchID).Scan(&nextSeq); err != nil {
			_ = tx.Rollback()
			writeError(w, r, http.StatusInternalServerError, "Erreur lors de la préparation du feedback")
			return
		}

		var insertedID int64
		var feedbackDate string
		err = tx.QueryRow(`
			INSERT INTO Feedback (match_id, seq_in_chat, user_id, message)
			VALUES ($1, $2, $3, $4)
			RETURNING id, TO_CHAR(feedback_date AT TIME ZONE 'UTC', 'YYYY-MM-DD"T"HH24:MI:SS"Z"')`,
			payload.MatchID, nextSeq, userID, payload.Message).Scan(&insertedID, &feedbackDate)
		if err != nil {
			_ = tx.Rollback()
			continue
		}

		if err := tx.Commit(); err != nil {
			continue
		}

		writeJSON(w, r, http.StatusCreated, map[string]any{
			"id":           insertedID,
			"matchId":      payload.MatchID,
			"seqInChat":    nextSeq,
			"userId":       userID,
			"message":      payload.Message,
			"feedbackDate": feedbackDate,
		})
		return
	}

	writeError(w, r, http.StatusConflict, "Impossible d'enregistrer le feedback pour le moment, réessaie")
}

func recalculateScoresHandler(w http.ResponseWriter, r *http.Request, db *sql.DB) {
	if handlePreflight(w, r) {
		return
	}
	if r.Method != http.MethodPost {
		writeError(w, r, http.StatusMethodNotAllowed, "Méthode non autorisée")
		return
	}

	_, err := db.Exec(`
		UPDATE UserPredictionHistory h
		SET actual_result = CASE
			WHEN m.home_score > m.away_score THEN 'HOME_WIN'
			WHEN m.away_score > m.home_score THEN 'AWAY_WIN'
			ELSE 'DRAW'
		END
		FROM Matches m
		WHERE h.match_id = m.id AND m.status = 'FINISHED'`)
	if err != nil {
		writeError(w, r, http.StatusInternalServerError, "Erreur lors de la mise à jour des résultats réels")
		return
	}

	_, _ = db.Exec(`
		INSERT INTO UserScores (user_id, score)
		SELECT id, 0 FROM "User"
		ON CONFLICT (user_id) DO NOTHING`)

	_, err = db.Exec(`
		UPDATE UserScores s
		SET score = computed.score
		FROM (
			SELECT h.user_id, COUNT(*)::INT AS score
			FROM UserPredictionHistory h
			WHERE h.actual_result IS NOT NULL
			  AND h.actual_result <> ''
			  AND h.predicted_result = h.actual_result
			GROUP BY h.user_id
		) AS computed
		WHERE s.user_id = computed.user_id`)
	if err != nil {
		writeError(w, r, http.StatusInternalServerError, "Erreur lors du recalcul des scores")
		return
	}

	_, _ = db.Exec(`
		UPDATE UserScores
		SET score = 0
		WHERE user_id NOT IN (
			SELECT DISTINCT user_id
			FROM UserPredictionHistory
			WHERE actual_result IS NOT NULL
			  AND actual_result <> ''
			  AND predicted_result = actual_result
		)`)

	writeJSON(w, r, http.StatusOK, map[string]string{"message": "Scores recalculés"})
}
